/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elescorpion4.mavenproject2;

import javax.swing.JOptionPane;

/**
 *
 * @author Elescorpion4
 */
public class parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        byte opcion = 0;
        int SOLGENERAL = 30;
        int SOLPREFERENTE = 50;
        int SOMBRA = 80;
        int TRIBUNA = 150;
        int PLATEA = 200;
        do {
            opcion = Byte.parseByte(JOptionPane.showInputDialog(
                    "***MENU PRINCIPAL***\n"
                    + "1. SOL GENERAL\n"
                    + "2. SOL PREFERENTE\n"
                    + "3. SOMBRA\n"
                    + "4. TRIBUNA\n"
                    + "5. PLATEA\n"
                    + "6. SALIR\n"
                    + "ELIJA SU SECTOR"));
            float numero1 = 0, resultado = 0;
            switch (opcion) {
                case 1:
                    numero1 = Float.parseFloat(JOptionPane.showInputDialog("Digite cantidad de boletas"));
                    resultado = numero1 * SOLGENERAL;
                    JOptionPane.showMessageDialog(null, "VALOR A CANCELAR " + resultado);

                    break;
                case 2:
                    numero1 = Float.parseFloat(JOptionPane.showInputDialog("Digite cantidad de boletas"));
                    resultado = numero1 * SOLPREFERENTE;
                    JOptionPane.showMessageDialog(null, "VALOR A CANCELAR " + resultado);

                    break;
                case 3:
                    numero1 = Float.parseFloat(JOptionPane.showInputDialog("Digite cantidad de boletas"));
                    resultado = numero1 * SOMBRA;
                    JOptionPane.showMessageDialog(null, "VALOR A CANCELAR " + resultado);

                    break;
                case 4:
                    numero1 = Float.parseFloat(JOptionPane.showInputDialog("Digite cantidad de boletas"));
                    resultado = numero1 * TRIBUNA;
                    JOptionPane.showMessageDialog(null, "VALOR A CANCELAR " + resultado);

                    break;
                case 5:
                    numero1 = Float.parseFloat(JOptionPane.showInputDialog("Digite cantidad de boletas"));
                    resultado = numero1 * PLATEA;
                    JOptionPane.showMessageDialog(null, "VALOR A CANCELAR " + resultado);

                    break;
                case 6:
                    opcion = 6;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion Invalida");
                    break;

            }

        } while (opcion != 6);
        System.exit(0);

    }

}
